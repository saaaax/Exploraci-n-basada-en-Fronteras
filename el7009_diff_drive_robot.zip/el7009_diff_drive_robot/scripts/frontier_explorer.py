#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped
from sklearn.cluster import DBSCAN
import numpy as np
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Odometry


class FrontierExplorer(Node):
    def __init__(self):
        super().__init__('frontier_explorer')

        self.subscription = self.create_subscription(
            OccupancyGrid,
            '/map',
            self.map_callback,
            10)

        self.goal_publisher = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.map_info = None

        self.current_pose = None  # para guardar la posición del robot

        self.pose_subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.pose_callback,
            10)


    def pose_callback(self, msg):
        self.current_pose = msg.pose.pose

    def map_callback(self, msg):
        self.map_info = msg.info
        width = msg.info.width
        height = msg.info.height
        data = np.array(msg.data).reshape((height, width))

        frontiers = self.detect_frontiers(data)
        if not frontiers:
            self.get_logger().info('No frontiers found.')
            return

        centroids = self.cluster_frontiers(frontiers)
        if not centroids:
            self.get_logger().info('No frontier centroids found.')
            return

        if self.current_pose is None:
            self.get_logger().info('No current robot pose available.')
            return

        # Ordenar las fronteras por distancia al robot
        robot_x = self.current_pose.position.x
        robot_y = self.current_pose.position.y

        centroids_sorted = sorted(
            centroids,
            key=lambda c: np.hypot(
                *np.subtract(self.grid_to_world(c[0], c[1]), (robot_x, robot_y))
            )
        )

        # Intentar publicar la primera frontera válida
        for cx, cy in centroids_sorted:
            wx, wy = self.grid_to_world(cx, cy)
            distance = np.hypot(wx - robot_x, wy - robot_y)
            if distance >= 0.5:
                self.publish_goal(cx, cy)
                return
            else:
                self.get_logger().info(f'Skipped close frontier ({wx:.2f}, {wy:.2f}) at {distance:.2f} m')

        self.get_logger().info('All frontier goals too close to robot.')


    def detect_frontiers(self, map_data):
        frontiers = []
        height, width = map_data.shape

        for y in range(1, height - 1):
            for x in range(1, width - 1):
                if map_data[y, x] == 0:
                    neighborhood = map_data[y-1:y+2, x-1:x+2]
                    if -1 in neighborhood:
                        frontiers.append((x, y))
        return frontiers

    def cluster_frontiers(self, frontiers):
        if len(frontiers) < 5:
            return frontiers

        clustering = DBSCAN(eps=3, min_samples=3).fit(frontiers)
        centroids = []

        for label in set(clustering.labels_):
            if label == -1:
                continue
            points = [frontiers[i] for i in range(len(frontiers)) if clustering.labels_[i] == label]
            cx = int(np.mean([p[0] for p in points]))
            cy = int(np.mean([p[1] for p in points]))
            centroids.append((cx, cy))

        return centroids

    def grid_to_world(self, x, y):
        res = self.map_info.resolution
        origin = self.map_info.origin.position
        wx = origin.x + (x + 0.5) * res
        wy = origin.y + (y + 0.5) * res
        return wx, wy

    def publish_goal(self, x, y):
        wx, wy = self.grid_to_world(x, y)

        if self.current_pose is None:
            self.get_logger().info('No current robot pose available.')
            return

        robot_x = self.current_pose.position.x
        robot_y = self.current_pose.position.y

        # robot_x, robot_y = 0.0, 0.0

        distance = np.hypot(wx - robot_x, wy - robot_y)
        if distance < 0.5:
            self.get_logger().info(f'Skipped goal too close to current pose ({distance:.2f} m)')
            return

        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x = wx
        goal.pose.position.y = wy
        goal.pose.position.z = 0.0
        goal.pose.orientation.x = 0.0
        goal.pose.orientation.y = 0.0
        goal.pose.orientation.z = 0.0
        goal.pose.orientation.w = 1.0

        self.goal_publisher.publish(goal)
        self.get_logger().info(
            f'Published goal to: geometry_msgs.msg.PoseStamped(header=std_msgs.msg.Header('
            f'stamp=builtin_interfaces.msg.Time(sec=0, nanosec=0), frame_id=\'map\'), '
            f'pose=geometry_msgs.msg.Pose(position=geometry_msgs.msg.Point(x={wx:.3f}, y={wy:.3f}, z=0.0), '
            f'orientation=geometry_msgs.msg.Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)))'
        )



def main(args=None):
    rclpy.init(args=args)
    node = FrontierExplorer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()